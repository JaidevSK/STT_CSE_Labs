﻿using System;
using System.Text;
using System.Threading;

int windowWidth;
int windowHeight;
char[,] scene;
int score = 0;
int carPosition;
int carVelocity;
bool gameRunning;
bool keepPlaying = true;
bool consoleSizeError = false;
int previousRoadUpdate = 0;


int width = Console.WindowWidth - 1;
int height = Console.WindowHeight - 1;



// Initializing the Time Delay
int timedelay = 100;

Console.CursorVisible = false;
try
{
    Initialize();
    LaunchScreen();
    while (keepPlaying)
    {
        InitializeScene();
        while (gameRunning)
        {
            if (Console.WindowHeight < height || Console.WindowWidth < width)
            {
                consoleSizeError = true;
                keepPlaying = false;
                break;
            }
            HandleInput();
            Update();
            Render();
            if (gameRunning)
            {
                Thread.Sleep(TimeSpan.FromMilliseconds(timedelay));
            }
        }
        if (keepPlaying)
        {
            GameOverScreen();
        }
    }
    Console.Clear();
    if (consoleSizeError)
    {
        Console.WriteLine("Console/Terminal window is too small.");
        Console.WriteLine($"Minimum size is {width} width x {height} height.");
        Console.WriteLine("Increase the size of the console window.");
    }
    Console.WriteLine("Drive was closed.");
}
finally
{
    Console.CursorVisible = true;
}

void Initialize()
{
    windowWidth = Console.WindowWidth;
    windowHeight = Console.WindowHeight;
    if (OperatingSystem.IsWindows())
    {
        if (windowWidth < width && OperatingSystem.IsWindows())
        {
            windowWidth = Console.WindowWidth = width + 1;
        }
        if (windowHeight < height && OperatingSystem.IsWindows())
        {
            windowHeight = Console.WindowHeight = height + 1;
        }
        Console.BufferWidth = windowWidth;
        Console.BufferHeight = windowHeight;
    }
}

void LaunchScreen()
{
    Console.Clear();
    Console.WriteLine("Welcome to the Driving Game.");
    Console.WriteLine();
    Console.WriteLine("Stay on the Road!");
    Console.WriteLine();
    Console.WriteLine("Use <, ^, and > to control your Direction.");
    Console.WriteLine();
    Console.BackgroundColor = ConsoleColor.Yellow;
    Console.ForegroundColor = ConsoleColor.Magenta;
    Console.WriteLine(@"
    ------------------------------\                     
    |   _________       _________  \                    
    |   |       |       |       |   \                   
    |   |       |       |       |    \                  
    |   |       |       |       |     \                 
    |   ---------       ---------     ------------      
    |                                          [] |     
    |                                             |     
    --------()---------------()--------------------     
");
    Console.ResetColor();
    // Taking Speed Input from User
    Console.WriteLine("Enter the speed of the car (1-3): ");
    int speed;
    while (true)
    {
        string input = Console.ReadLine();
        if (int.TryParse(input, out speed) && speed >= 1 && speed <= 3)
        {
            timedelay = 150 / speed;
            break;
        }
        else
        {
            Console.WriteLine("Invalid input. Please enter a number between 1 and 3.");
        }
    }
    Console.Write("Press [enter] to start...");
    PressEnterToContinue();
    Console.Clear();
}

void InitializeScene()
{
    const int roadWidth = 10;
    gameRunning = true;
    carPosition = width / 2;
    carVelocity = 0;
    int leftEdge = (width - roadWidth) / 2;
    int rightEdge = leftEdge + roadWidth + 1;
    scene = new char[height, width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            if (j < leftEdge || j > rightEdge)
            {
                scene[i, j] = '.';
            }
            else
            {
                scene[i, j] = ' ';
            }
        }
    }
}

void Render()
{
    StringBuilder stringBuilder = new(width * height);
    for (int i = height - 1; i >= 0; i--)
    {
        for (int j = 0; j < width; j++)
        {
            if (i is 1 && j == carPosition)
            {
                //stringBuilder.Append(
                //    !gameRunning ? 'X' :
                //    carVelocity < 0 ? '<' :
                //    carVelocity > 0 ? '>' :
                //    '^');
                Console.SetCursorPosition(j, i);
                Console.BackgroundColor = ConsoleColor.Red;
                Console.ForegroundColor = ConsoleColor.Yellow;
                char car = !gameRunning ? 'X' : carVelocity < 0 ? '<' : carVelocity > 0 ? '>' : 'V';
                Console.Write(car);
                Console.ResetColor();
            }
            else
            {
                //stringBuilder.Append(scene[i, j]);
                if (scene[i, j] is ' ')
                {
                    //stringBuilder.Append(' ');
                    Console.SetCursorPosition(j, i);
                    Console.BackgroundColor = ConsoleColor.Gray;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write(' ');
                    Console.ResetColor();
                }
                else
                {
                    //stringBuilder.Append(scene[i, j]);
                    Console.SetCursorPosition(j, i);
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write(scene[i, j]);
                    Console.ResetColor();
                }
            }
        }
        if (i > 0)
        {
            stringBuilder.AppendLine();
        }
    }
    //Console.SetCursorPosition(0, 0);
    //Console.BackgroundColor = ConsoleColor.Green;
    //Console.ForegroundColor = ConsoleColor.White;
    //Console.Write(stringBuilder);
    //Console.ResetColor();
    //Console.SetCursorPosition(1, carPosition);
    //Console.BackgroundColor = ConsoleColor.Green;
    //Console.ForegroundColor = ConsoleColor.White;
    //char car = !gameRunning ? 'X' : carVelocity < 0 ? '<' : carVelocity > 0 ? '>' : '^';
    //Console.Write(car);
    //Console.ResetColor();
}

void HandleInput()
{
    while (Console.KeyAvailable)
    {
        ConsoleKey key = Console.ReadKey(true).Key;
        switch (key)
        {
            case ConsoleKey.A or ConsoleKey.LeftArrow:
                carVelocity = -1;
                break;
            case ConsoleKey.D or ConsoleKey.RightArrow:
                carVelocity = +1;
                break;
            case ConsoleKey.W or ConsoleKey.UpArrow or ConsoleKey.S or ConsoleKey.DownArrow:
                carVelocity = 0;
                break;
            case ConsoleKey.Escape:
                gameRunning = false;
                keepPlaying = false;
                break;
            case ConsoleKey.Enter:
                Console.ReadLine();
                break;
        }
    }
}

void GameOverScreen()
{   
    Console.Clear();
    Console.SetCursorPosition(0, 0);
    Console.WriteLine("Game Over");
    Console.WriteLine($"Score: {score}");
    Console.WriteLine($"Play Again (Y/N)?");
GetInput:
    ConsoleKey key = Console.ReadKey(true).Key;
    switch (key)
    {
        case ConsoleKey.Y:
            keepPlaying = true;
            break;
        case ConsoleKey.N or ConsoleKey.Escape:
            keepPlaying = false;
            break;
        default:
            goto GetInput;
    }
}

void Update()
{
    for (int i = 0; i < height - 1; i++)
    {
        for (int j = 0; j < width; j++)
        {
            scene[i, j] = scene[i + 1, j];
        }
    }
    int roadUpdate =
        Random.Shared.Next(5) < 4 ? previousRoadUpdate :
        Random.Shared.Next(3) - 1;
    if (roadUpdate is -1 && scene[height - 1, 0] is ' ') roadUpdate = 1;
    if (roadUpdate is 1 && scene[height - 1, width - 1] is ' ') roadUpdate = -1;
    switch (roadUpdate)
    {
        case -1: // left
            for (int i = 0; i < width - 1; i++)
            {
                scene[height - 1, i] = scene[height - 1, i + 1];
            }
            scene[height - 1, width - 1] = '.';
            break;
        case 1: // right
            for (int i = width - 1; i > 0; i--)
            {
                scene[height - 1, i] = scene[height - 1, i - 1];
            }
            scene[height - 1, 0] = '.';
            break;
    }
    previousRoadUpdate = roadUpdate;
    carPosition += carVelocity;
    if (carPosition < 0 || carPosition >= width || scene[1, carPosition] is not ' ')
    {
        gameRunning = false;
    }
    score++;
}

void PressEnterToContinue()
{
GetInput:
    ConsoleKey key = Console.ReadKey(true).Key;
    switch (key)
    {
        case ConsoleKey.Enter:
            break;
        case ConsoleKey.Escape:
            keepPlaying = false;
            break;
        default: goto GetInput;
    }
}