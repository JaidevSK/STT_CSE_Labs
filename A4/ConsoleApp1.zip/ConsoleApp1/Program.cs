﻿using System;

namespace ConsoleApp1
{
    // Publisher
    class AlarmClockPublisher // Publisher class
    {
        public event EventHandler RaiseAlarm; // Raise Alarm event handler is defined here  
        public void SetTime(string sTime) // This method sets the time for the alarm
        {
            while (true) 
            {
                string currentTime = DateTime.Now.ToString("HH:mm:ss"); // Get the current time 
                if (currentTime == sTime) 
                {
                    RaiseAlarm?.Invoke(this, EventArgs.Empty);  // If the time matches, invoke the event
                    break;
                }
                else
                {
                    Console.WriteLine("Current Time: " + currentTime); // Otherwise write the current time
                    System.Threading.Thread.Sleep(1000); // Wait for 1 second before checking again
                }
            }
        }
    }

    // Subscriber
    class AlarmClockSubscriber
    {
        public static void Ring_alarm(object sender, EventArgs e)
        {
            Console.WriteLine("ALARM CLOCK RINGING AT " + DateTime.Now.ToString("HH:mm:ss")); // The ring alarm methid prints the message to the console
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Current Time: " + DateTime.Now.ToString("HH:mm:ss")); // Display the current time
            Console.WriteLine("Enter the time in HH:MM:SS format:"); // Prompt the user to enter the time   
            string userTime = Console.ReadLine(); // Take the user inut
            if (userTime.Length != 8 || !TimeSpan.TryParse(userTime, out _)) // Checking the user input format
            {
                Console.WriteLine("Invalid time format. Please enter time in HH:MM:SS format.");
                return;
            }
            else
            {
                Console.WriteLine("Alarm set for: " + userTime);
            }
            AlarmClockPublisher publisher = new AlarmClockPublisher(); // We create new subscriber and publisher objects
            AlarmClockSubscriber subscriber = new AlarmClockSubscriber();
            publisher.RaiseAlarm += AlarmClockSubscriber.Ring_alarm; // We subscribe to the event of the publisher
            publisher.SetTime(userTime);  // Then, we set the time with the given user input
        }
    }
}