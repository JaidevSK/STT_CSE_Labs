using Microsoft.VisualBasic.ApplicationServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrayNotify;
using System.Diagnostics.Metrics;
using Timer = System.Windows.Forms.Timer;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent(); // I Initialize the Components
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string inputTime = textBox1.Text; // I take the text from the textbox
            TimeSpan targetTime; // Then I set the target as the targer time

            if (!TimeSpan.TryParse(inputTime, out targetTime)) // If there us any parsing error, I return an error message box
            {
                MessageBox.Show("Invalid time format. Please enter time in HH:MM:SS format.");
                return;
            }

            Timer timer = new Timer(); // I initialize the timer
            timer.Interval = 1000; // 1 second is the intetrval
            timer.Tick += (s, args) => // In every tick, I change to a random colour and if the time is exceeding, I show the message
            {
                this.BackColor = Color.FromArgb( // Random Colour assigned
                    Random.Shared.Next(256),
                    Random.Shared.Next(256),
                    Random.Shared.Next(256));

                if (DateTime.Now.TimeOfDay >= targetTime) // If the time exceeds we give the alarm
                {
                    timer.Stop();
                    MessageBox.Show("Target time reached!");
                }
            };
            timer.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.White; // I load the form with white colour
        }


    }
}
