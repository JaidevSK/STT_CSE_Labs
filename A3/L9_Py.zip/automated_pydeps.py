import os

os.makedirs("images", exist_ok=True)
os.makedirs("jsonresults", exist_ok=True)

for filename in os.listdir("bert"):
    if filename.endswith(".py"):
        os.system(f"pydeps --reverse --pylib --rankdir BT --show-deps -o images/{filename}.svg bert/{filename} > jsonresults/{filename}.json")
        continue
    else:
        continue


