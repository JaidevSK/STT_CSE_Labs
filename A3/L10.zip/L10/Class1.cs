﻿using System;
namespace L10;

public class Class1
{
	public void Q2()
	{
		Console.WriteLine("Enter your First Number:");
        int Number1 = Convert.ToInt32(Console.ReadLine());
		Console.WriteLine("Enter your Second Number:");
		int Number2 = Convert.ToInt32(Console.ReadLine());

		int addition = Number1 + Number2;
		int subtraction = Number1 - Number2;
		int multiplication = Number1 * Number2;
		int division = Number1 / Number2;

		Console.WriteLine("The Addition Result is:", addition);
		Console.WriteLine("The Subtraction Result is:", subtraction);
        Console.WriteLine("The Multiplication Result is:", multiplication);
        Console.WriteLine("The Division Result is:", division);

		if (addition > 0)
		{
			Console.WriteLine("The Sum is Positive");
		}
		else if (addition < 0)
		{
			Console.WriteLine("The Sum is Negative");
		}
		else
		{
			Console.WriteLine("The Sum is Zero");
		}
    }
}
