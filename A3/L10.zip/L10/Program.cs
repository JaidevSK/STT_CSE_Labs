﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace L10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("+++++++++++++++Entering Lab Activity (1)+++++++++++++++++++++++++");
            Console.WriteLine("hello world !");


            Console.WriteLine("+++++++++++++++Entering Lab Activity (2)+++++++++++++++++++++++++");
            Console.WriteLine("Enter your First Number:");
            int Number1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter your Second Number:");
            int Number2 = int.Parse(Console.ReadLine());

            int addition = Number1 + Number2;
            int subtraction = Number1 - Number2;
            int multiplication = Number1 * Number2;
            int division = Number1 / Number2;

            Console.WriteLine($"The Addition Result is: {addition}");
            Console.WriteLine($"The Subtraction Result is: {subtraction}");
            Console.WriteLine($"The Multiplication Result is: {multiplication}");
            Console.WriteLine($"The Division Result is:{division}");

            if (addition > 0)
            {
                Console.WriteLine("The Sum is Positive");
            }
            else if (addition < 0)
            {
                Console.WriteLine("The Sum is Negative");
            }
            else
            {
                Console.WriteLine("The Sum is Zero");
            }


            Console.WriteLine("+++++++++++++++Entering Lab Activity (3)+++++++++++++++++++++++++");
            Console.WriteLine("Printing from 1 to 10");
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("To Exit the Loop, Type 'exit'");
            while (true)
            {
                string input_str = Console.ReadLine();
                if (input_str == "exit")
                {
                    break;
                }
                else
                {
                    continue;
                }
            }

            // Factorial Calculation
            int Factorial(int num)
            {
                if (num < 0)
                {
                    Console.WriteLine("Invalid Number");
                    return -1;
                }
                else if (num == 0)
                {
                    return 1;
                }
                return num * Factorial(num - 1);
            }

            Console.WriteLine("Enter the Number for Factorial:");
            int input_num_factorial = int.Parse(Console.ReadLine());
            int fact_answer = Factorial(input_num_factorial);
            Console.WriteLine($"The factorial of {input_num_factorial} is {fact_answer}");

            Console.WriteLine("+++++++++++++++Entering Lab Activity (4)+++++++++++++++++++++++++");
            Student someone = new Student("Someone", "22110000", 99);
            Console.WriteLine(someone.ToString());

            StudentIITGN student_iitgn = new StudentIITGN("Someone", "22110000", 99, "Hostel K");
            Console.WriteLine(student_iitgn.ToString());



            Console.WriteLine("Enter your First Number:");
            int Number1_try = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter your Second Number:");
            int Number2_try = int.Parse(Console.ReadLine());

            Console.WriteLine("+++++++++++++++Entering Lab Activity (5)+++++++++++++++++++++++++");
            try
            {
                int division_errorhandled = Number1_try / Number2_try;
                Console.WriteLine($"The Division Result is:{division_errorhandled}");
            }
            catch(Exception e)
            {
                if (e is DivideByZeroException)
                {
                    Console.WriteLine("Division by Zero is not allowed");
                }
                else
                {
                    Console.WriteLine("Some other Exception");
                }
            }

            Console.WriteLine("+++++++++++++++Lab Activities 1-5 Completed+++++++++++++++++++++++++");
            Console.WriteLine("+++++++++++++++Debugging in Lab Activity (6)+++++++++++++++++++++++++");




        }
    }
}


public class Student
{
    string Name;
    string ID;
    int Marks;

    public Student(string name, string id, int marks)
    {
        this.Name = name;
        this.ID = id;
        this.Marks = marks;
    }

    public string getGrade()
    {
        if (this.Marks > 90)
        {
            return "A";
        }
        else if (this.Marks > 80)
        {
            return "B";
        }
        else if (this.Marks > 70)
        {
            return "C";
        }
        else
        {
            return "FAIL";
        }
    }

    public override String ToString()
    {
        string grade = this.getGrade();
        return "Student Name: " + this.Name +
            "\nStudent ID: " + this.ID +
            "\nStudent Marks: " + this.Marks +
            "\nStudent Grade: " + grade;
    }
}


public class StudentIITGN : Student
{
    string Hostel_Name_IITGN;

    public StudentIITGN(string name, string id, int marks, string hostel_name) : base(name, id, marks)
    {
        this.Hostel_Name_IITGN = hostel_name;
    }

    public override string ToString()
    {
        return base.ToString() + "\nHostel Name: " + this.Hostel_Name_IITGN;
    }
}