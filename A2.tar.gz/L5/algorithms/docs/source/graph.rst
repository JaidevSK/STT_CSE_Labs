.. role:: hidden
    :class: hidden-section

algorithms.graph
=================
