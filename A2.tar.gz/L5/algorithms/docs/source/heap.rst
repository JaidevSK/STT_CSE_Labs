.. role:: hidden
    :class: hidden-section

algorithms.heap
=================
